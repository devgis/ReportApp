/**
 * @author: Yang Zhang
 * @module:
 * @export:
 * @date: 2016/8/12
 */
var loginBtn = $("#login");
var logName = $(".logName");
var logPass = $(".logPass");
var yzCode = $(".yzCode");
var toast = $(".toast");





//去掉字符串前后空格；
function Trim(str) {
    return str.replace(/(^\s*)|(\s*$)/g, "");
}

