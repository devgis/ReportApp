(function($, window, document, undefined) {
	//定义分页类
	function Paging(element, options) {
		this.element = element;
		//传入形参
		this.options = {
			pageNo: options.pageNo||1,
			totalPage: options.totalPage,
			totalSize:options.totalSize,
			callback:options.callback
		};
		//根据形参初始化分页html和css代码
		this.init();
	}
	//对Paging的实例对象添加公共的属性和方法
	Paging.prototype = {
		constructor: Paging,
		init: function() {
			this.creatHtml();
			this.bindEvent();
		},
		creatHtml: function() {
			var me = this;
			var content = "";
			var current = me.options.pageNo;
			var total = me.options.totalPage;
			var totalNum = me.options.totalSize;
			content += "<a id=\"firstPage\"></a><a id='prePage'></a>";		
			content += "<a id='currentPages'>"+current+"</a>";
			content += "<a id='totalPages'> "+"/"+total+"页"+"</a>";
			content += "<a id='nextPage'></a>";
			content += "<a id=\"lastPage\"></a>";
			me.element.html(content);
		},
		//添加页面操作事件
		bindEvent: function() {
			var me = this;
			me.element.on('click', 'a', function() {
				var num = $(this).html();
				var id=$(this).attr("id");
				if(id == "prePage") {
					if(me.options.pageNo == 1) {
						me.options.pageNo = 1;

						console.log("数据条数；"+me.options.totalSize)
					 	console.log("每页显示数；"+15)
					 	console.log("总页码数："+me.options.totalPage)
						console.log($(".table_item").length)
						$(".table_item").addClass("hidden")
						for(var i=0;i<15;i++){
							$(".table_item").eq(i).removeClass("hidden")
						}


					} else {
						me.options.pageNo = +me.options.pageNo - 1;

						console.log(me.options.pageNo)
						$(".table_item").addClass("hidden")
						/*console.log(15*(me.options.pageNo-1))
						console.log(15*me.options.pageNo)*/
						for(var i=15*(me.options.pageNo-1);i<15*me.options.pageNo;i++){
							$(".table_item").eq(i).removeClass("hidden")
						}


					}
				} else if(id == "nextPage") {
					if(me.options.pageNo == me.options.totalPage) {
						me.options.pageNo = me.options.totalPage

						console.log(me.options.pageNo)
						console.log(me.options.totalSize)

						$(".table_item").addClass("hidden");
						for(var i=(me.options.pageNo-1)*15;i<me.options.totalSize;i++){
							$(".table_item").eq(i).removeClass("hidden")
						}



					} else {
						me.options.pageNo = +me.options.pageNo + 1;
						var end =15*me.options.pageNo;
						if(15*me.options.pageNo>me.options.totalSize){
							end = me.options.totalSize
						}
						

						$(".table_item").addClass("hidden")
						for(var i=15*(me.options.pageNo-1);i<end;i++){
							$(".table_item").eq(i).removeClass("hidden")
						}


					}

				} else if(id =="firstPage") {
					me.options.pageNo = 1;
					$(".table_item").addClass("hidden")
					for(var i=0;i<15;i++){
						$(".table_item").eq(i).removeClass("hidden")
					}


				} else if(id =="lastPage") {
					me.options.pageNo = me.options.totalPage;
					console.log(me.options.pageNo)
					$(".table_item").addClass("hidden");
					for(var i=(me.options.pageNo-1)*15;i<me.options.totalSize;i++){
						$(".table_item").eq(i).removeClass("hidden")
					}

				}else{
					me.options.pageNo = +num;
				}
				me.creatHtml();
				if(me.options.callback) {
					me.options.callback(me.options.pageNo);
				}
			});
		}
	};
	//通过jQuery对象初始化分页对象
	$.fn.paging = function(options) {
		return new Paging($(this), options);
	}
})(jQuery, window, document);